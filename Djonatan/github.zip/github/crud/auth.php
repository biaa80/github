<?php
require_once 'config.php';
require_once 'users/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = trim($_POST['username']); 
    $password = $_POST['password'];

    $conn = open_database();

    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
    $stmt->bind_param("ss", $input, $input);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if (password_verify($password, $user['password'])) {
       
            $_SESSION['user'] = [
                'id' => $user['id'],
                'name' => $user['name'],
                'username' => $user['username'],
                'email' => $user['email'],
                'access_level' => $user['access_level']
            ];

            header("Location: index.php");
            exit;
        } else {
            echo "<script>alert('Senha incorreta!');window.location='login.php';</script>";
        }
    } else {
        echo "<script>alert('Usuário não encontrado!');window.location='login.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>