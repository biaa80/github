<?php

$nome_banco= "C6 Bank";
$nome_cliente= "Beatriz";
$email= "biavieira11.live@gmail.com";
$numero= "(41) 99758-1817";
$data= "05/12/2008";
$endereco= "R. Doutor Cerqueira Lima, 364, São Braz, Curitiba - PR";
$senha= "123";

echo "Bem-vindo(a), Beatriz! Sua cota foi criada com sucesso.";

?>