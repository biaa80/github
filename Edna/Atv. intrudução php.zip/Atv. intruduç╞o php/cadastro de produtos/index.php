<?php

$codigo_acesso= 123;

$produto1= "Gloss Bruna Tavares";
$qtde1= 1000;
$preco1= 50.00;
$total1= ($qtde1 * $preco1);

$produto2= "Gloss Franciny Ehlke liphoney ";
$qtde2= 1750;
$preco2= 70.00;
$total2= ($qtde2 * $preco2);

$produto3= "Gloss Kiko Milano";
$qtde3= 2000;
$preco3= 90.00;
$total3= ($qtde3 * $preco3);

$total4= ($total1 + $total2 + $total3)

echo "Gloss Bruna Tavares: 1000 em estoque." . "<br>";
echo "Gloss Franciny Ehlke liphoney: 1750 em estoque." . "<br>";
echo "Gloss Kiko Milano: 2000 em estoque." . "<br>";




?>