<?php

$codigo_acesso= 123;

$produto1= "Base Mari Maria";
$qtde1= 1000;
$preco1= 50.00;
$total1= ($qtde1 * $preco1);

$produto2= "Base Bruna Tavares";
$qtde2= 1750;
$preco2= 70.00;
$total2= ($qtde2 * $preco2);

$produto3= "Base Fran";
$qtde3= 2000;
$preco3= 90.00;
$total3= ($qtde3 * $preco3);

$total4= ($total1 + $total2 + $total3)

echo "Base Mari Maria: 870 em estoque." . "<br>";
echo "Base Bruna Tavares: 2289 em estoque." . "<br>";
echo "Base Fran: 1967 em estoque." . "<br>";




?>