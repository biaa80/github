<?php

$nome_banco= "Inter";
$nome_cliente= "Gabrielle";
$email= "gabyrcoelho20@gmail.com";
$numero= "(41) 99569-7837";
$data= "01/10/2009";
$endereco= "BR 116 Linha Verde, 15480, Curitiba - PR";
$senha= "123";

echo "Bem-vindo(a), Gabrielle! Sua conta foi criada com sucesso.";

?>