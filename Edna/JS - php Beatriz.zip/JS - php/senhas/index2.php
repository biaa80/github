<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alteração de senha</title>
    <script src="script2.js"></script>
</head>
<body>
<h1>Formulário de alteração de senha</h1>

<form action="" onsubmit="return validar()" method="post">
    <label for="email">E-mail:</label>
    <input type="text" id="email" name="email"><br><br>

    <label for="senha">Senha:</label>
    <input type="number" id="senha" name="senha"><br><br>

    <label for="confirmacao">Confirmação:</label>
    <input type="number" id="confirmacao" name="confirmacao"><br><br>

    <input type="submit" value="Verificar">
</form>

</body>
</html>