<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscrição para concurso</title>
    <script src="script5.js"></script>
</head>
<body>
<h1>Formulário de inscrição para consurso</h1>

<form action="" onsubmit="return validar()" method="post">
    <label for="cpf">CPF:</label>
    <input type="number" id="cpf" name="cpf"><br><br>

    <label for="idade">Idade:</label>
    <input type="number" id="idade" name="idade"><br><br>

    <input type="submit" value="Inscrever">
</form>

</body>
</html>