<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesquisa</title>
    <script src="script3.js"></script>
</head>
<body>
<h1>Formulário pesquisa</h1>

<form action="" onsubmit="return validar()" method="post">
    <label for="pesquisa">Pesquisar:</label>
    <input type="text" id="pesquisa" name="pesquisa"><br><br>

    <input type="submit" value="Avançar">
</form>

</body>
</html>