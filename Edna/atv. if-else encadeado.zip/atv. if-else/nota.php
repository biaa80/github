<?php

$nota= 8;

if($nota == 9 || $nota == 10){
    echo "Nota excelente";
}elseif($nota == 7 || $nota == 8){
    echo "Nota boa";
}elseif($nota == 5 || $nota == 6){
    echo "Nota regular";
}else{
    echo "Nota insuficiente";
}


?>